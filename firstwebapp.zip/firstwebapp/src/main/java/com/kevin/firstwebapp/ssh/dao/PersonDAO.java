package com.kevin.firstwebapp.ssh.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.kevin.firstwebapp.ssh.entity.Person;

@Repository
public class PersonDAO {

	public List<Person> getPersons() {
		return null;
	}

	public void addPerson(Person person) {

	}

	public void updatePerson(Person person) {

	}

	public void deletePerson(Person person) {

	}
}
